﻿using DevComponents.Tree;

namespace CW_Mind_Mapper_1
{
    class Gib
    {
        public static TreeGX nowmmap;

        public static string[] tabfile = new string[1000];
        public static bool[] saved = new bool[1000];
        //public static bool[] allsaved = new bool[1000];
    }
}
/*

try
{
}
catch { }
*/
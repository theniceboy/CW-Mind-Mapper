using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;

namespace CW_Mind_Mapper_1
{
    public partial class FrmHelp : DevComponents.DotNetBar.Metro.MetroForm
    {
        public FrmHelp()
        {
            InitializeComponent();
        }
    }
}